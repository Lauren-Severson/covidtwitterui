r = getOption("repos")
r["CRAN"] = "http://cran.rstudio.com"
options(repos = r)

if (!require("DT")) {
  install.packages("DT")
  library(DT)
}

if (!require("ggplot2")) {
  install.packages("ggplot2")
  library(ggplot2)
}

if (!require("knitr")) {
  install.packages("knitr")
  library(knitr)
}

if(!require('dplyr')) {
  install.packages("dplyr")
  library(dplyr)
}

if(!require('stringr')) {
  install.packages("stringr")
  library(stringr)
}

if(!require('Rtsne')) {
  install.packages("Rtsne")
  library(Rtsne)
}

if(!require('stopwords')) {
  install.packages("stopwords")
  library(stopwords)
}

if(!require('plotly')) {
  install.packages("plotly")
  library(plotly)
}

if (!require("kableExtra")) {
  install.packages("kableExtra")
  library(kableExtra)
}

if (!require("wordcloud2")) {
  install.packages("wordcloud2")
  library(wordcloud2)
}

if (!require("tidytext")) {
  install.packages("tidytext")
  library(tidytext)
}

if (!require("tm")) {
  install.packages("tm")
  library(tm)
}

if (!require("ggrepel")) {
  install.packages("ggrepel")
  library(ggrepel)
}

if (!require("shinyWidgets")) {
  install.packages("shinyWidgets")
  library(shinyWidgets)
}

if (!require("shinycssloaders")) {
  install.packages("shinycssloaders")
  library(shinycssloaders)
}

knitr::opts_chunk$set(echo = TRUE)

source("Elasticsearch.R")

if (!require("syuzhet")) {
  install.packages("syuzhet")
  library(syuzhet)
}

if (!require("shinycssloaders")) {
  install.packages("shinycssloaders")
  library(shinycssloaders)
}

if (!require("rintrojs")) {
  install.packages("rintrojs")
  library(rintrojs)
}

if (!require("png")) {
  install.packages("png")
  library(png)
}
if (!require("shinydashboard")) {
  install.packages("shinydashbard")
  library(shinydashboard)
}

if (!require("grid")) {
  install.packages("grid")
  library(grid)
}



#range start
rangestart <- "2020-04-01 00:00:00"

#range end
rangeend <- "2020-04-20 00:00:00"

text_filter<-""

#query semantic similarity phrase 
semantic_phrase <- ""

#(ignored if semantic_phrase is not blank)
random_sample <- FALSE

#number of results to return (max 10,000)
resultsize <- 1000

show_original_subcluster_plots <- FALSE
show_regrouped_subcluster_plots <- TRUE
show_word_freqs <- FALSE
show_center_nn <- FALSE